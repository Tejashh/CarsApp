package com.example.tejashcontractor.proj2;

/*
    Name: Tejash Contractor
    Project 2: Car Application which involves both Grid and LIstView including Context Menu and Long
               Click event:
    CS478
    Date: Oct 13, 2018
    University Of Illinois At Chicago
 */

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import static com.example.tejashcontractor.proj2.MainActivity.urls;

public class activity_grid_item extends MainActivity {

    TextView gridData;      //textview gridData
    ImageView imageView;    // imageView ImageView


    //
    // onCreate():
    //
    // onCreate method which displays received Image from MainActivity plus open
    // URL associaed with the car company:
    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_item);

        gridData = findViewById(R.id.android_gridview_text); //take id form griddate to gridData
        imageView = findViewById(R.id.android_gridview_image);   //take id of imageView
        Intent intent = getIntent();
        final int receivedImage = intent.getIntExtra("image",0);    //receive Image from Main Activity

        imageView.setImageResource(receivedImage);  //setting image

        //
        //OnClickListener which clickes single view on the image and opens up
        // URL on web brewser:
        //
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(urls[MainActivity.pos]));
                startActivity(intent);
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);  //Enabling Back button
    }

    //
    //OnOptionItemSelected which creates back button on menu bar
    //
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = new Intent(activity_grid_item.this,MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}//End of the activity_grid_item class:
