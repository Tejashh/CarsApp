package com.example.tejashcontractor.proj2;

/*
    Name: Tejash Contractor
    Project 2: Car Application which involves both Grid and LIstView including Context Menu and Long
               Click event:
    CS478
    Date: Oct 13, 2018
    University Of Illinois At Chicago
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

//
// CustomAdapter class:
//
// ClassWhich creates customAddapter for GridView:
//
public class CustomAdapter extends BaseAdapter {

    Context mContext;
    String[] carName;
    int[] carImages;

    //Constructor that creates CutomAdapter which works with context, carName, carImages
    public CustomAdapter(Context context, String[] carName, int[] carImages) {
        mContext = context;
        this.carName = carName;
        this.carImages = carImages;
    }

    @Override
    public int getCount() {
        return carName.length;  //getting the length of the carName array
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View contextView, ViewGroup parent) {
        View gridView1;
        LayoutInflater inflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        //when contextView is null:
        if (contextView == null) {

            gridView1 = new View(mContext);
            gridView1 = inflater.inflate(R.layout.row_data, null);  //instantiate xml to object
            TextView textView = (TextView) gridView1.findViewById(R.id.name); // xml to object
            ImageView imageView = (ImageView) gridView1.findViewById(R.id.images); // xml to object
            textView.setText(carName[position]);
            imageView.setImageResource(carImages[position]);
        } else {
            gridView1 = (View) contextView;
        }

        return gridView1;   //returning the view
    }
}// end of the CUstomAdapter Class:
