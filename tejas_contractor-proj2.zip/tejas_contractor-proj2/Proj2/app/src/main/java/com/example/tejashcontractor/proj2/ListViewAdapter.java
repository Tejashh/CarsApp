package com.example.tejashcontractor.proj2;

/*
    Name: Tejash Contractor
    Project 2: Car Application which involves both Grid and LIstView including Context Menu and Long
               Click event:
    CS478
    Date: Oct 13, 2018
    University Of Illinois At Chicago
 */

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class ListViewAdapter extends ArrayAdapter<String>{
    public ListViewAdapter(@NonNull Context context, int resource) {
        super(context, resource);
    }

    String[] carName;   //initializing carName String array:
    String[] manufaturerAddress;    //initializing manufacturerAddress String array;
    Context context; //initializing Context

    //ListViewAdatper Constructor which store careName into carName:
    public ListViewAdapter(Context context, String[] carName, String[] manufaturerAddress) {
        super(context,R.layout.listviewadapter,carName);
        this.carName = carName;
        this.manufaturerAddress = manufaturerAddress;
        this.context = context;

    }

    public View getView(int position, View contextView, ViewGroup parent){
        LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contextView = layoutInflater.inflate(R.layout.listviewadapter,null);    //instantiate listviewadapter as object from xml
        TextView textView = (TextView) contextView.findViewById(R.id.textView3); //textView object from xml
        TextView textView1 = (TextView) contextView.findViewById(R.id.textView4); //textView1 object from xml

        textView.setText(carName[position]);    //setting text name of Carname in each cell
        textView1.setText(manufaturerAddress[position]);    //setting text of adress in each cell
        return contextView; //returning contextView:
    }
}//End of the ListViewAdater class:
