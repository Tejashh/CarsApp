package com.example.tejashcontractor.proj2;

/*
    Name: Tejash Contractor
    Project 2: Car Application which involves both Grid and LIstView including Context Menu and Long
               Click event:
    CS478
    Date: Oct 13, 2018
    University Of Illinois At Chicago
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Main2Activity extends MainActivity{
    ListView listView;

    //
    // OnCreate method which allows to open new activity with listView:
    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        listView = (ListView) findViewById(R.id.list); //listview object from xml file
        Intent intent = getIntent();    //intent
        String receivedName =  intent.getStringExtra("name");   //receving name

        //System.out.println("->>>>>>>>>>>>>>>>>>>>>>>>>" + receivedName + "..............." +receivedName.length());

        /************************************************************************************************************************************************************/
        //
        // Strings which are going to use for name and address which will add into LIstView:
        //
        String[] mazdaName = {"The Autobarn City Mazda", "The Autobarn Mazda of Evanston", "Wilkins Mazda"};
        String[] mazdaAddress = {"3255 N Cicero Ave","1015 Chicago Ave, Evanston, IL 60202","740 N York St, Elmhurst, IL 60126"};
        String[] mercedesName = {"Top Car Motors","Mercedes-Benz of Chicago","Greater Chicago Motors"};
        String[] mercedesAddress = {"5480 N Elston Ave, Chicago, IL 60630","1520 W North Ave, Chicago, IL 60642","1850 N Elston Ave, Chicago, IL 60642"};
        String[] toyotaCamryName = {"Chicago Northside Toyota","Toyota On Western","Grossinger City Toyota"};
        String[] toyotaCampryAddress = {"6042 N Western Ave, Chicago, IL 60659","6941 S Western Ave, Chicago, IL 60636","1561 N Fremont St, Chicago, IL 60642"};
        String[] audiName ={"Top Car Motors","Chicago Auto Place","Napleton Automotive Group"};
        String[] audiAddress = {"5480 N Elston Ave, Chicago, IL 60630"," 768 Thomas Dr, Bensenville, IL 60106","10400 W Higgins Rd, Rosemont, IL 60018"};
        String[] dougeChargerName = {"Napleton's Northwestern Chrysler Jeep Dodge Ram","Sherman Dodge Chrysler Jeep Ram","Marino Chrysler Jeep Dodge"};
        String[] dougeChargerAddress = {"5950 N Western Ave, Chicago, IL 60659","7601 Skokie Blvd, Skokie, IL 60077","5133 W Irving Park Rd, Chicago, IL 60641"};
        String[] hondaCivicName = {"Honda City Chicago","McGrath City Honda","North City Honda"};
        String[] hondaCivicAdress = {"4950 S Pulaski Rd, Chicago, IL 60632","6720 W Grand Ave, Chicago, IL 60707","6600 N Western Ave, Chicago, IL 60645"};
        String[] hondaAccordName = {"Honda City Chicago","McGrath City Honda","North City Honda"};
        String[] hondaAccordAddress = {"4950 S Pulaski Rd, Chicago, IL 60632","6720 W Grand Ave, Chicago, IL 60707","6600 N Western Ave, Chicago, IL 60645"};
        String[] nisaanMaximaName = {"Berman Nissan of Chicago","Star Nissan","Al Piemonte Nissan"};
        String[] nissanMaximaAddress = {"3456 N Kedzie Ave, Chicago, IL 60618","5757 W Touhy Ave, Niles, IL 60714","1600 W North Ave, Melrose Park, IL 60160"};
        String[] fordMustangName = {"Victor Ford","Golf Mill Ford","Fox Ford Lincoln"};
        String[] fordMustangAddress = {"1400 N US Hwy 12, Wauconda, IL 60084","9401 N Milwaukee Ave, Niles, IL 60714","2501 N Elston Ave, Chicago, IL 60647"};

        /***********************************************************************************************************************************************************/

        //Initializing two arrays name carName and manufaturerAddess with length of 3 space:
        String[] carName = new String[3];
        String[] manufaturerAddress = new String[3];

        /*************************************************************************/
        //If Else statements which comapres the name selected with manual name:
        if(receivedName.equals("Mazda 3"))  //if selected item is Mazda
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = mazdaName[i];
                manufaturerAddress[i] = mazdaAddress[i];
            }
        }
        else if(receivedName.equals("Mercedes 2014")) //if selected item is Mercedes 2014
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = mercedesName[i];
                manufaturerAddress[i] = mercedesAddress[i];
            }
        }
        else if(receivedName.equals("Toyota Camry")) //if selected item is Toyota Camry
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = toyotaCamryName[i];
                manufaturerAddress[i] = toyotaCampryAddress[i];
            }
        }
        else if(receivedName.equals("Audi")) //if selected item is Audi
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = audiName[i];
                manufaturerAddress[i] = audiAddress[i];
            }
        }
        else if(receivedName.equals("Dodge Charger")) //if selected item is Dodge Charger
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = audiName[i];
                manufaturerAddress[i] = audiAddress[i];
            }
        }
        else if(receivedName.equals("Honda Civic")) //if selected item is Honda Civic
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = hondaCivicName[i];
                manufaturerAddress[i] = hondaCivicAdress[i];
            }
        }
        else if(receivedName.equals("Honda Accord")) //if selected item is Honda Accord
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = hondaAccordName[i];
                manufaturerAddress[i] = hondaAccordAddress[i];
            }
        }
        else if(receivedName.equals("Nissan Maxima")) //if selected item is Nissan Maxima
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = nisaanMaximaName[i];
                manufaturerAddress[i] = nissanMaximaAddress[i];
            }
        }
        else if(receivedName.equals("Ford Mustang")) //if selected item is Ford Mustang
        {
            for(int i = 0 ; i < 3; i++)
            {
                carName[i] = fordMustangName[i];
                manufaturerAddress[i] = fordMustangAddress[i];
            }
        }

        /**************************************************************************/


        //Initialzing LIstViewAdapter:
        ListViewAdapter ad = new ListViewAdapter(this,carName,manufaturerAddress);

        //setting up LIstview Adapter with listView:
        listView.setAdapter(ad);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);  //Enabling Back button

    }   //ENd of the onCrete Method:

    //
    //OnOptionItemSelected which creates back button on menu bar
    //
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            super.onBackPressed();
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}//End of the Main2Activity:
