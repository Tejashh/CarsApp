package com.example.tejashcontractor.proj2;

/*
    Name: Tejash Contractor
    Project 2: Car Application which involves both Grid and LIstView including Context Menu and Long
               Click event:
    CS478
    Date: Oct 13, 2018
    University Of Illinois At Chicago
 */
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    GridView gridView;      //Declaration of gridview
    public static int pos;    //Global int variable

    //Car names String array:
    String[] carNames = {"Mazda 3","Mercedes 2014","Toyota Camry",
            "Audi","Dodge Charger","Honda Civic","Honda Accord",
            "Nissan Maxima","Ford Mustang"};

    //Car image with its drawable integer value
    int[] carImages = {R.drawable.mazda,R.drawable.mercedes_2014,
            R.drawable.toyota_camry_2019,R.drawable.audir8,
            R.drawable.dodge_charger,R.drawable.honda_civic,
            R.drawable.honda_accord,R.drawable.nissan_maxima,
            R.drawable.ford_mustang,};

    //URLS which takes user to dealers official website (IT is a string array)
    public static String[] urls = {"https://www.mazdausa.com/vehicles/mazda3-sedan?semid=408-534-47-82&providertag=MazdaSEM&servicetag=408-534-47-82&t=1&k_clickid=562bb042-1303-4765-b723-eb89d46b766a&k_keyword=%20mazda3&k_matchtype=Broad&gclid=Cj0KCQjw6fvdBRCbARIsABGZ-vQPegFKV4gauP7pE6IstJO9LDsZapxilBkd_hG4-DOnHwERVzw0WAIaApLTEALw_wcB",
    "https://www.mbusa.com/en/home?sd_campaign_type=Search&sd_digadprov=Resolution&sd_campaign=ZZBrand%7CCorp%7CMisc%7CGeneral%7CExact&sd_channel=GOOGLE&sd_adid=General&sd_digadkeyword=mercedes+benz+official+site&gclid=Cj0KCQjw6fvdBRCbARIsABGZ-vTMhmW6DdcG4uOZZZri8jkebvyo-eeS97yamD853xuc4g-anMoLJqwaAgHaEALw_wcB&gclsrc=aw.ds",
    "https://www.toyota.com/camry/camry-features/?srchid=sem:GOOGLE:Model_Camry:Camry_Info_Website&gclid=Cj0KCQjw6fvdBRCbARIsABGZ-vTKvnFXl_yUbEf7RwFD163yR98JLUR69SqC75vXGEZmBrTFzxRel3YaAiDwEALw_wcB&gclsrc=aw.ds",
    "https://audioffers.com/chicagoland/index.htm?ds_kid=43700023397561921&ddcref=phd_AOPaidSearch_FY17&gclid=Cj0KCQjw6fvdBRCbARIsABGZ-vSpoD0YdVtKh-Tg1DR953DH6M1Jr0VPGfbsFVH9AYMEaQZqx1ftO-4aAiYuEALw_wcB&gclsrc=aw.ds&geoZip=60018",
    "https://www.dodge.com",
    "https://www.northcityhonda.com/search/new-civic-chicago-il/?cy=60633&tp=new&md=126&gclid=Cj0KCQjw6fvdBRCbARIsABGZ-vShAarNCFa1jGOMWL-59_p1sagYUmAuUBPgCi3P6sHGJW8zU48_NiEaAjgLEALw_wcB",
    "https://www.northcityhonda.com/search/new-accord-chicago-il/?cy=60633&tp=new&md=124&gclid=Cj0KCQjw6fvdBRCbARIsABGZ-vS1ou-aLU4o6Krn1e63vJdNUaCwTcz-xc8ygN-IVy4m_pyDgxPkGfAaAv1ZEALw_wcB",
    "https://www.nissanusa.com/vehicles/cars/maxima/build-price.html?&dcp=psn.58700002284570190&gclid=Cj0KCQjw6fvdBRCbARIsABGZ-vTPgmFkjatgZr_f5KDyp9pNZizXvkDY7RoiNurkclEJ1jblIKt1WEUaAhlpEALw_wcB&gclsrc=aw.ds&dclid=CP-qso6kgN4CFQfDwAod0SoAIw#configure/A/version",
    "https://www.ford.com/cars/mustang/?gclid=Cj0KCQjw6fvdBRCbARIsABGZ-vTGmWk-kUbBGOGsa-K-db-46tUnx76pfJw3SICUfRVS0dKqoeD4wL4aAnPkEALw_wcB&searchid=1569140292%7C61057453842%7C333323670880%7C&ef_id=Cj0KCQjw6fvdBRCbARIsABGZ-vTGmWk-kUbBGOGsa-K-db-46tUnx76pfJw3SICUfRVS0dKqoeD4wL4aAnPkEALw_wcB:G:s&s_kwcid=AL!2519!3!295604282281!b!!g!!%2Bmustang%20%2Bwebsite"};

    //
    // OnCreate method which allows user to click on the view
    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



            //finding listview
            gridView = findViewById(R.id.gridView);

            //Cteating customAdapter:
            CustomAdapter customAdapter = new CustomAdapter(MainActivity.this, carNames, carImages);

            //setting custom adapter with gridview
            gridView.setAdapter(customAdapter);

            //
            // OnItemClickLIstener():
            //
            //ON CLick Action Listener which allows user to single click on gridview and go to next
            // activity which allows user to do further work (VIew full image, plus view the official website):
            //
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    Intent intent = new Intent(getApplicationContext(), activity_grid_item.class);
                    intent.putExtra("name", carNames[i]);
                    intent.putExtra("image", carImages[i]);
                    startActivity(intent);  //Starting new activity
                }
            });

            //
            // OnItemLongCLickListener():
            //
            //on click Listener which allow user to long click on gridview and open context manu which are described
            //bellow:
            //
            gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
                    registerForContextMenu(gridView);   //registering the context menu on long click so that
                    // it will run onCreteContextMenu() and
                    // onContextItemSelected() bellow:
                    openContextMenu(gridView);          //Opening the context menu on MainActivity
                    pos = position;                       //Storing position into pos
                    //set the image as wallpaper
                    return true;
                }
            });

    }

    //
    // onCreateContextMenu():
    //
    //It create the context menu whenever the long click is clicked on the grid view cell:
    //

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();  //initializing MenuInflator as inflater
        inflater.inflate(R.menu.context, menu); //intantiate context.xml into menu object.
    }


    //
    //onContextItemSelected():
    //
    //THis method is created to select the menu option shown in context view:
    //
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        //Context menu bring up addapterview
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        switch(item.getItemId()) {

            //option 3 is selected

            case R.id.option3:
                nearestLocation();
                return true;
            //option1 is seleted:
            case R.id.option1:
                fullImage();
                return true;
            //option 2 is selected:
            case R.id.option2:
                officialWebsite();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //
    // fullImage():
    //
    // method which opens new activity (activity_grid_item) and desplay full image of car:
    //
    private void fullImage() {
        Intent intent = new Intent(getApplicationContext(),activity_grid_item.class);
            intent.putExtra("name", carNames[pos]);
            intent.putExtra("image", carImages[pos]);
            startActivity(intent);
    }

    //
    //officialWebsite():
    //
    //Method which opens official Website of the selected car manufaturer:
    //
    private void officialWebsite() {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setData(Uri.parse(urls[pos]));
        startActivity(intent);
    }

    //
    // nearestLocation()
    //
    // opens up new activity (Main2Acitivity) and display listview which has three nearest locations
    // name and adresses:
    //
    private void nearestLocation(){
        Intent intent = new Intent(getApplicationContext(),Main2Activity.class);
        intent.putExtra("name",carNames[pos]);
        intent.putExtra("image",carImages[pos]);
        startActivity(intent);
    }



}//End of the MainActivity Method: